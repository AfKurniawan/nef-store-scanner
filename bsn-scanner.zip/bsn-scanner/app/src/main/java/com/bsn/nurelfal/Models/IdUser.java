package com.bsn.nurelfal.Models;

public class IdUser {

    String id_user;

    public IdUser(){}


    public IdUser(String id_user) {
        this.id_user = id_user;


    }

    public String getId_user() {
        return id_user;
    }



    // SET VOID


    public void setId_user(String id_user) {
        this.id_user = id_user;
    }
}
